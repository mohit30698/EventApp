//package com.event.app.event.service;
//
//import org.junit.Test;
//import org.springframework.web.client.RestTemplate;
//
//import com.event.app.event.model.EventList;
//
//import static org.junit.Assert.assertNotNull;
//
//public class EventServiceTest {
//
//	@Test
//	public void givenGetAllEventsThenShouldReturnListOfAllEvents() {
//
//		RestTemplate restTemplate = new RestTemplate();
//		EventService eventService = new EventServiceImpl(restTemplate);
//		EventList list = eventService.getAllEvents();
//		assertNotNull(list);
//
//	}
//
//}
//
//
