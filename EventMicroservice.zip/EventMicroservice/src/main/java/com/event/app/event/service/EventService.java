package com.event.app.event.service;

import com.event.app.event.model.EventList;

public interface EventService {

	public EventList getAllEvents();

}
