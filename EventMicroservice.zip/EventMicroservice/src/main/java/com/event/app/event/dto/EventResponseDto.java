package com.event.app.event.dto;

import java.util.List;

import com.event.app.event.model.Event;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class EventResponseDto {

	   private List<Event> data;

	   public EventResponseDto(List<Event> data) {
	      super();
	      this.data = data;
	   }
	}



