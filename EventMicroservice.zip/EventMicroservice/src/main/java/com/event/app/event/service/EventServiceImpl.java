package com.event.app.event.service;

import org.slf4j.Logger;

import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.event.app.event.model.EventList;




@Service
public class EventServiceImpl implements EventService {
	
	Logger logger=LoggerFactory.getLogger(EventServiceImpl.class);
	
	String API_URL="https://api.seatgeek.com/2/events?client_id=Mzg0MjM2NzJ8MTcwMDQ4Mjk5OS42ODE4Nzc5";
   private final RestTemplate restTemplate;

	public EventServiceImpl(RestTemplate restTemplate) {
		this.restTemplate = restTemplate;
	}

	public EventList getAllEvents() {
		
		//logger.info("Retrieved all events from 3rd party URL");
		return restTemplate.getForObject(API_URL, EventList.class);

	}
}

