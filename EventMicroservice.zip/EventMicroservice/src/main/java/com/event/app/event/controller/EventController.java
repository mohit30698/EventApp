package com.event.app.event.controller;
import java.util.Map;



import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.event.app.event.exception.ExternalServiceException;
import com.event.app.event.exception.InvalidCredentialsException;
//import com.event.app.event.feign.AuthClient;
import com.event.app.event.model.EventList;
import com.event.app.event.service.EventService;


import io.swagger.v3.oas.annotations.Parameter;


@CrossOrigin
@RestController
@RequestMapping("/api/v1.0/eventService")
public class EventController {

	Logger logger=LoggerFactory.getLogger(EventController.class);
	
    private final EventService service;
  //  private final AuthClient authClient;

    public EventController(EventService service) {
        this.service = service;
        //this.authClient=authClient;
    }
    
    @GetMapping("/viewAll")
    public ResponseEntity<EventList> getAllEvents(@Parameter(hidden=true) @RequestHeader("Authorization") String token)
    {
     logger.info("Retrieved all events from 3rd party URL successfully");
       return new ResponseEntity<>(service.getAllEvents(),HttpStatus.OK);
    }
}
   // public ResponseEntity<EventList> getAllEvents(@Parameter(hidden=true) @RequestHeader("Authorization") String token)
    //{
//    	
//    	  public ResponseEntity<EventList> getAllEvents(@Parameter(hidden=true) @RequestHeader("Authorization") String token)  {
////    	   try {
////    		      Map<String, String> userInfo = (Map<String, String>) authClient.validateToken(token).getBody();
////    		      if (userInfo.containsValue("ROLE_CUSTOMER")) {
////    		    	  return new ResponseEntity<>(service.getAllEvents(),HttpStatus.OK);
////    		      } else {
////    		         throw new InvalidCredentialsException("Access Denied");
////    		      }
////    		   } catch (FeignException e) {
////    		      throw new ExternalServiceException(e.getMessage());
////    		   }
////
////    		}
//}
////    		}
////    	    
//    	    {
//    	logger.info("Retrieved all events from 3rd party URL successfully");
//    	return new ResponseEntity<>(service.getAllEvents(),HttpStatus.OK);
//    }
//}
////
////
////
////@GetMapping("/country/{country}")
////@Operation(summary = "listing stocks by countrys")
////public ResponseEntity<?> getStocksByCountry(@PathVariable String country,
////      @Parameter(hidden = true) @RequestHeader("Authorization") String token)
////
////
////
////
////	
////	