//package com.cts.event.app.auth.kafka;
//
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.kafka.annotation.KafkaListener;
//import org.springframework.stereotype.Service;
//
//import com.cts.event.app.auth.dto.UserProfile;
//import com.cts.event.app.auth.service.UserService;
//import com.fasterxml.jackson.core.JsonProcessingException;
//import com.fasterxml.jackson.databind.ObjectMapper;
//import com.google.gson.Gson;
//
//
//@Service
//public class JsonKafkaConsumer {
//   
//   @Autowired
//   UserService userService;
//   
//   @Autowired
//   Gson gson;
//   
//   //for consuming data from kafka and register the user
//    private static final Logger LOGGER = LoggerFactory.getLogger(JsonKafkaConsumer.class);
//
//    @KafkaListener(topics = "${spring.kafka.topic-json.name}", groupId = "${spring.kafka.consumer.group-id}")
//    public void consume(String user) throws JsonProcessingException{
//     LOGGER.info(String.format("Json message recieved -> %s", user.toString()));
////     UserProfile userProfile = gson.fromJson(user.toString(), UserProfile.class);
//     UserProfile userProfile = convertToJavaObject(user);
//      userService.registerUser(userProfile);
//        //user registeration using kafka
//    }
//    private UserProfile convertToJavaObject(String message) throws JsonProcessingException {
//      UserProfile userDetails=new ObjectMapper().readValue(message, UserProfile.class);
//     LOGGER.info("from Converter"+userDetails+"-----");
//      return  userDetails;
//  }
//}