package com.cts.event.app.auth.service;

import java.util.List;
import java.util.Optional;

import org.springframework.http.ResponseEntity;

import com.cts.event.app.auth.dto.LoginDto;
import com.cts.event.app.auth.dto.SignupDto;
import com.cts.event.app.auth.dto.UserProfile;
import com.cts.event.app.auth.entity.User;



public interface UserService {

	   public ResponseEntity<?> addUser(SignupDto signupDto);
	   
//	   kafka service
	   public ResponseEntity<?> registerUser(UserProfile signupDto);

	   // this will work like a authentication manager for validating user

	   public boolean loginUser(LoginDto loginDto);

	   public List<User> getAllUsers();

	   public Optional<User> getUserByUsername(String username);


	}