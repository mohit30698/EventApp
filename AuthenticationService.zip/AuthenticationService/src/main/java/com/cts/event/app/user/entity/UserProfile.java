//package com.cts.event.app.user.entity;
//
//import lombok.AllArgsConstructor;
//import lombok.Getter;
//import lombok.NoArgsConstructor;
//import lombok.Setter;
//import lombok.ToString;
//
//@Getter
//@Setter
//@AllArgsConstructor
//@NoArgsConstructor
//@ToString
//
//public class UserProfile {
//   private long id;
//   private String username;
//   private String email;
//   private String password;
//
//
//}