package com.cts.event.app.auth.exception;

import java.util.Date;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.cts.event.app.auth.entity.ErrorResponseDto;

import jakarta.servlet.http.HttpServletRequest;

@RestControllerAdvice
public class GlobalExceptionHandler {

   @ResponseStatus(code = HttpStatus.CONFLICT)
   @ExceptionHandler({ InvalidInputException.class })
   public ErrorResponseDto InvalidInputTException(Exception exception, HttpServletRequest request) {
      return new ErrorResponseDto(new Date(), HttpStatus.CONFLICT.value(), HttpStatus.CONFLICT.getReasonPhrase(),
            exception.getMessage(), request.getRequestURI());
   }

}