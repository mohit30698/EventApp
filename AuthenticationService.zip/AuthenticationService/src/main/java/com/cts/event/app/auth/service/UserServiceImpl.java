package com.cts.event.app.auth.service;

import java.util.HashMap;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.cts.event.app.auth.dto.LoginDto;
import com.cts.event.app.auth.dto.SignupDto;
import com.cts.event.app.auth.dto.UserProfile;
import com.cts.event.app.auth.entity.User;
import com.cts.event.app.auth.exception.InvalidInputException;
import com.cts.event.app.auth.repo.UserRepository;


@Service
public class UserServiceImpl implements UserService {
   
	@Autowired
   private UserRepository userRepository;


   Map<String, String> mapObj = new HashMap<>();

   @Override
   public ResponseEntity<?> addUser(SignupDto signupDto) {
      if (userRepository.existsByUsername(signupDto.getUsername())
            || userRepository.existsByEmail(signupDto.getEmail())) {
         mapObj.put("msg", "Username or email is already exists!");
         return new ResponseEntity<>(mapObj, HttpStatus.BAD_REQUEST);
      }
//      User user = new User(signupDto.getId(),signupDto.getUsername(),signupDto.getFirstName(),signupDto.getLastName(),signupDto.getPassword(),signupDto.getEmail(),signupDto.getNumber());
      User user = new User(signupDto.getUsername(), signupDto.getPassword(), signupDto.getEmail());
      userRepository.save(user);
      mapObj.put("msg", "User registered successfully");
      return new ResponseEntity<>(mapObj, HttpStatus.OK);
   }

   @Override
   public boolean loginUser(LoginDto loginRequest) {

      Optional<User> userObj = userRepository.findByUsername(loginRequest.getUsername());
      if (userObj.isPresent() && userObj.get().getPassword().equals(loginRequest.getPassword())) {
         return true;
      }
      return false;
   }



   @Override
   public Optional<User> getUserByUsername(String username) {
      Optional<User> user = userRepository.findByUsername(username);
      if (user.isEmpty()) {
         throw new InvalidInputException("username is not present");
      }
      return user;
   }

   @Override
   public List<User> getAllUsers() {
      return userRepository.findAll();
   }



   //user registeration using kafka
 
   @Override
   public ResponseEntity<?> registerUser(UserProfile userProfileDto) {
      if (userRepository.existsByUsername(userProfileDto.getUsername())
            || userRepository.existsByEmail(userProfileDto.getEmail())) {
         mapObj.put("msg", "Username or email is already exists!");
         return new ResponseEntity<>(mapObj, HttpStatus.BAD_REQUEST);
      }
      User user = new User(userProfileDto.getUsername(), userProfileDto.getPassword(), userProfileDto.getEmail());
    

      userRepository.save(user);
      mapObj.put("msg", "User registered successfully");
      return new ResponseEntity<>(mapObj, HttpStatus.OK);
   }





}