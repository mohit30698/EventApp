package com.cts.event.app.auth.controller;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.event.app.auth.dto.JwtResponse;
import com.cts.event.app.auth.dto.LoginDto;
import com.cts.event.app.auth.dto.SignupDto;
import com.cts.event.app.auth.entity.User;
import com.cts.event.app.auth.exception.InvalidInputException;
import com.cts.event.app.auth.security.JwtTokenUtil;
import com.cts.event.app.auth.service.UserService;
@CrossOrigin
@RestController
@RequestMapping("/api/v1.0/authentication")
public class AuthorizationController {
   
	@Autowired
   UserService userService;
   
	@Autowired
   JwtTokenUtil jwtTokenUtil;
  
	//backup endpoint for user registeration in case kafka fails
   
	@PostMapping("/signup")
   public ResponseEntity<?> registerUser(@RequestBody SignupDto signUpRequest) {
      try {
         return userService.addUser(signUpRequest);
      } catch (InvalidInputException e) {
         return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
      }
   }
   @PostMapping("/login")
   public ResponseEntity<?> loginUser(@RequestBody LoginDto loginRequest) throws InvalidInputException {
      try {
         String jwtToken = jwtTokenUtil.generatToken(loginRequest);
         Optional<User> userDetails = userService.getUserByUsername(loginRequest.getUsername());// fetch the user
         if (userDetails.isPresent()) {
            return ResponseEntity.ok(new JwtResponse(jwtToken, userDetails.get().getId(),
                  userDetails.get().getUsername(), userDetails.get().getEmail()));
         } else {
            throw new InvalidInputException("Invalid Credentials");
         }
      } catch (InvalidInputException e) {
         return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(e.getMessage());
      }
   }
 
   @PostMapping("/validate")
   public ResponseEntity<?> validateToken(@RequestHeader("Authorization") String token) {
      if (jwtTokenUtil.validateJwtToken(token)) {
         return ResponseEntity.status(HttpStatus.OK).body(jwtTokenUtil.validateJwtToken(token));
      } else {
         return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(false);
      }
   }

   @GetMapping("/getAllUsers")
   public ResponseEntity<?> getAllUsers(@RequestHeader("Authorization") String token) {
      Map<String, String> responseObj = new HashMap<>();
      responseObj.put("msg", "access denied");
      if (jwtTokenUtil.validateJwtToken(token)) {
         return new ResponseEntity<>(userService.getAllUsers(), HttpStatus.OK);
      } else {
         return ResponseEntity.status(HttpStatus.FORBIDDEN).body(responseObj);
      }
   }

}
 