//package com.cts.event.app.auth.service;
//
//import com.cts.event.app.auth.dto.LoginDto;
//import com.cts.event.app.auth.dto.SignupDto;
//import com.cts.event.app.auth.dto.UserProfile;
//import com.cts.event.app.auth.entity.User;
//import com.cts.event.app.auth.exception.InvalidInputException;
//import com.cts.event.app.auth.repo.UserRepository;
//
//import org.jose4j.jwk.Use;
//import org.junit.jupiter.api.Assertions;
//import org.junit.jupiter.api.Test;
//import org.junit.jupiter.api.extension.ExtendWith;
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
//import org.mockito.Mockito;
//import org.mockito.junit.jupiter.MockitoExtension;
//
//import java.util.Arrays;
//import java.util.HashMap;
//import java.util.Map;
//import java.util.Optional;
//
//@ExtendWith(MockitoExtension.class)
//public class UserServiceImplTest {
//    @InjectMocks
//    UserServiceImpl userService;
//    @Mock
//    UserRepository userRepository;
//
//    @Mock
//    Map<String, String> mapObj = new HashMap<>();
//
//    @Test
//    public void addUser() {
//        SignupDto signupDto = new SignupDto(1, "mani", "mani@gmail.com", "abcs", null, null, null);
//         Mockito.when(userRepository.existsByUsername(signupDto.getUsername())
//                 || userRepository.existsByEmail(signupDto.getEmail())).thenReturn(true);
//         userService.addUser(signupDto);
//
//    }
//    @Test
//    public void addUser_() {
//        SignupDto signupDto = new SignupDto(1, "mani", "mani@gmail.com", "abcs", null, null, null);
//        User user= new User( signupDto.getId(), signupDto.getUsername(),signupDto.getPassword(), signupDto.getEmail());
////        Mockito.when( userRepository.save(user)).thenReturn(user);
//       Mockito.when( mapObj.put("msg", "User registered successfully")).thenReturn("ok");
//        userService.addUser(signupDto);
//
//
//    }
//    @Test
//    public void loginUser() {
//        User user= new User(1l, "abc", "abc","abc");
//        LoginDto loginDto= new LoginDto("abc","abc");
//        Mockito.when(userRepository.findByUsername(loginDto.getUsername())).thenReturn(Optional.of(user));
//        userService.loginUser(loginDto);
//    }
//
//    @Test
//    public void loginUser_for_false() {
//        User user= new User(1l, "xyz", "abc","xyz");
//        LoginDto loginDto= new LoginDto("abc","abc");
//        Mockito.when(userRepository.findByUsername(loginDto.getUsername())).thenReturn(Optional.of(user));
//        userService.loginUser(loginDto);
//    }
//    @Test
//    public void getUserByUsername() {
//        User user= new User(1l, "xyz", "abc","xyz");
//      //  LoginDto loginDto= new LoginDto("abc","abc");
//        Mockito.when(userRepository.findByUsername("xyz")).thenReturn(Optional.of(user));
//        userService.getUserByUsername("xyz");
//    }
//    @Test
//    public void getUserByUsername_User_empty() {
//        User user= new User(1l, "", "abc","xyz");
//
//        Mockito.when(userRepository.findByUsername("xyz")).thenReturn(Optional.empty());
//        Assertions.assertThrows(InvalidInputException.class,  ()-> userService.getUserByUsername("xyz"));
//    }
//
//    @Test
//    public void getAllUsers() {
//        User user= new User(1l, "xyz", "abc","xyz");
//      Mockito.when(userRepository.findAll()).thenReturn(Arrays.asList(user));
//      userService.getAllUsers();
//    }
//
//    @Test
//    public void registerUser() {
//        UserProfile userProfileDto = new UserProfile(1l, "abc","abc","abc", null, null, null, null);
//        User user= new User(1l, "abc", "abc","abc");
//        Mockito.when(userRepository.existsByUsername(userProfileDto.getUsername())
//                || userRepository.existsByEmail(userProfileDto.getEmail())).thenReturn(true);
//        userService.registerUser(userProfileDto);
//    }
//
//}
