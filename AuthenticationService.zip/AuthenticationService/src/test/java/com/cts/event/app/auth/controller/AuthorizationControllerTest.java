//package com.cts.event.app.auth.controller;
//
//import com.cts.event.app.auth.dto.LoginDto;
//import com.cts.event.app.auth.entity.User;
//import com.cts.event.app.auth.exception.InvalidInputException;
//import com.cts.event.app.auth.security.JwtTokenUtil;
//import org.junit.jupiter.api.Test;
//import org.junit.jupiter.api.extension.ExtendWith;
//import org.junit.runner.RunWith;
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
//import org.mockito.Mockito;
//import org.mockito.junit.MockitoJUnitRunner;
//import org.mockito.junit.jupiter.MockitoExtension;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.HttpStatusCode;
//import org.springframework.http.ResponseEntity;
//
//import com.cts.event.app.auth.dto.SignupDto;
//import com.cts.event.app.auth.service.UserService;
//
//import ch.qos.logback.core.status.Status;
//
//import java.util.Optional;
//
//@ExtendWith(MockitoExtension.class)
//class AuthorizationControllerTest {
//	@InjectMocks
//	AuthorizationController authorizationController;
//	
//	@Mock
//	UserService userService;
//
//	@Mock
//	JwtTokenUtil jwtTokenUtil;
//	
//	@Test
//	public void registerUser() {
//		ResponseEntity responseEntity = new ResponseEntity(HttpStatus.CREATED);
//		SignupDto signupDto = new SignupDto(1, "mani", "mani@gmail.com", "abcs", null, null, null);
//		Mockito.when(userService.addUser(signupDto)).thenReturn(responseEntity);
//		authorizationController.registerUser(signupDto);
//	}
//	@Test
//	public void registerUser_BAD_REQUEST() {
//		ResponseEntity responseEntity = new ResponseEntity(HttpStatus.BAD_REQUEST);
//		SignupDto signupDto = new SignupDto(1, "mani", "mani@gmail.com", "abcs", null, null, null);
//		Mockito.when(userService.addUser(signupDto)).thenThrow(new InvalidInputException("error"));
//		authorizationController.registerUser(signupDto);
//	}
//	@Test
//	public void loginUser() {
//		ResponseEntity responseEntity = new ResponseEntity(HttpStatus.BAD_REQUEST);
//		LoginDto loginDto= new LoginDto("priya", "priya");
//		Mockito.when(jwtTokenUtil.generatToken(loginDto)).thenReturn("abc");
//		Mockito.when( userService.getUserByUsername(loginDto.getUsername())).thenReturn(Optional.of(new User()));
//		authorizationController.loginUser(loginDto);
//	}
//	@Test
//	public void loginUser_InvalidInputException() {
//		LoginDto loginDto= new LoginDto("priya", "priya");
//		Mockito.when(jwtTokenUtil.generatToken(loginDto)).thenReturn("abc");
//		Mockito.when( userService.getUserByUsername(loginDto.getUsername())).thenThrow(new InvalidInputException("Invalid Credentials"));
//		authorizationController.loginUser(loginDto);
//	}
//	@Test
//	public void validateToken() {
//		Mockito.when(jwtTokenUtil.validateJwtToken("token")).thenReturn(true);
//		authorizationController.validateToken("token");
//	}
//	@Test
//	public void validateToken_false() {
//		Mockito.when(jwtTokenUtil.validateJwtToken("token")).thenReturn(false);
//		authorizationController.validateToken("token");
//	}
//	@Test
//	public void getAllUsers() {
//		Mockito.when(jwtTokenUtil.validateJwtToken("token")).thenReturn(true);
//		authorizationController.getAllUsers("token");
//	}
//	@Test
//	public void getAllUsers_exception() {
//		Mockito.when(jwtTokenUtil.validateJwtToken("token")).thenReturn(false);
//		authorizationController.getAllUsers("token");
//	}
//}