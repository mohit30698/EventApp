package com.cts.event.app.user.service;

import java.util.List;

import java.util.Optional;
import java.util.stream.Stream;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;


import com.cts.event.app.user.dto.UserProfileDto;
import com.cts.event.app.user.entity.UserProfile;
import com.cts.event.app.user.exception.ResourceAlreadyExistsException;
import com.cts.event.app.user.exception.ResourceNotFoundException;
import com.cts.event.app.user.repo.UserProfileRepo;


@Service
public class UserProfileServiceImp implements UserProfileService {

	private final UserProfileRepo usersProfileRepository;

	private final ModelMapper modelMapper;

	private final BCryptPasswordEncoder bCryptPasswordEncoder;

	@Autowired
	public UserProfileServiceImp(UserProfileRepo usersProfileRepository, ModelMapper modelMapper,
			BCryptPasswordEncoder bCryptPasswordEncoder) {
		
		this.usersProfileRepository = usersProfileRepository;
		this.modelMapper = modelMapper;
		this.bCryptPasswordEncoder = bCryptPasswordEncoder;
	}

//	@Override
//	public List<UserProfileDto> getAllUsers() {
//
//		return Stream.of(usersProfileRepository.findAll())
//				.flatMap(entityList -> entityList.stream().map(entity -> modelMapper.map(entity, UserProfileDto.class)))
//				.toList();
//
//	}

	@Override
	public UserProfileDto getUserProfileById(long id) {
		UserProfile entity = usersProfileRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Entity not found with ID: " + id));

		return modelMapper.map(entity, UserProfileDto.class);
	}

	@Override
//	public UserProfileDto saveUserProfile(UserProfile userProfile) {
//
//		if (usersProfileRepository.existsByUsername(userProfile.getUsername())
//				|| usersProfileRepository.existsByEmail(userProfile.getEmail())) {
//			throw new ResourceAlreadyExistsException("UserProfile already exists");
//		}

	public UserProfileDto saveUserProfile(UserProfile userProfile) {
		// TODO Auto-generated method stub
		
		if (usersProfileRepository.findByUsername(userProfile.getUsername()).isPresent()) {
            throw new ResourceAlreadyExistsException("username already exists: " + userProfile.getUsername());
        }
		  
		userProfile.setPassword(bCryptPasswordEncoder.encode(userProfile.getPassword()));
		return modelMapper.map(usersProfileRepository.save(userProfile), UserProfileDto.class);
		
	}

	@Override
	public UserProfileDto updateUserProfile(UserProfileDto userProfileDTO, long id) {
		UserProfile entity = usersProfileRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("UserProfile not found with ID: " + id));

		entity.setEmail(userProfileDTO.getEmail());
		entity.setFirstName(userProfileDTO.getFirstName());
		entity.setLastName(userProfileDTO.getLastName());
		entity.setNumber(userProfileDTO.getNumber());
//		entity.setDateOfBirth(userProfileDTO.getDateOfBirth());
	
		usersProfileRepository.save(entity);

		return modelMapper.map(entity, UserProfileDto.class);
	}
	
//	@Override
//	 public UserProfileDto updateUserProfile(UserProfileDto userProfileDto, long id) {
//
//	        // Check if the user with the given userId exists
//	        Optional<UserProfile> optionalUser = usersProfileRepository.findById(id);
//	        if (optionalUser.isPresent()) {
//	            UserProfile existingUser = optionalUser.get();
//	            // Update the fields with the new values
//	            existingUser.setUsername(userProfileDto.getUsername());
//	            existingUser.setFirstName(userProfileDto.getFirstName());
//	            existingUser.setLastName(userProfileDto.getLastName());
//	            existingUser.setNumber(userProfileDto.getNumber());
//	            existingUser.setPassword(userProfileDto.getPassword());
//	            existingUser.setEmail(userProfileDto.getEmail());
//	            existingUser.setDateOfBirth(userProfileDto.getDateOfBirth());
//	            
//	            // Save the updated user
//	            return usersProfileRepository.save(existingUser);
//	        } else {
//	            throw new ResourceNotFoundException("User not found with id: " + id);
//	        }
//	}
////
//	@Override
//	public Optional<UserProfile> getUserByUsername(String username) {
//		Optional<UserProfile> user = usersProfileRepository.findByUsername(username);
//		if (user.isEmpty()) {
//			throw new ResourceNotFoundException("UserProfile not found with username: " + username);
//		}
//		return user;
//	}

}