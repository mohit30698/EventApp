package com.cts.event.app.user.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Data
@Getter
@Setter

@Entity
@Table(name = "users")
public class User {

  @Id
   @GeneratedValue(strategy = GenerationType.IDENTITY)
   private Long id;
	private String username;
	
//	private String firstName;
//	
//	private String lastName;
	
	

	private String password;
	
	private String email;
//   
//	private String number;
	
	public User(String username, String password, String email) {
		super();
		this.username = username;
		this.password = password;
		this.email = email;
	}
}

