package com.cts.event.app.user.controller;

import org.slf4j.LoggerFactory;

import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.event.app.user.dto.UserProfileDto;
import com.cts.event.app.user.entity.UserProfile;
import com.cts.event.app.user.exception.ResourceAlreadyExistsException;
import com.cts.event.app.user.exception.ResourceNotFoundException;
import com.cts.event.app.user.kafka.JsonKafkaProducer;
//import com.cts.event.app.user.kafka.JsonKafkaProducer;
import com.cts.event.app.user.service.UserProfileService;
@CrossOrigin
@RestController
@RequestMapping("/api/v1.0/userProfile")

public class UserProfileController {
	
	private final UserProfileService usersProfileService;
	
	private final JsonKafkaProducer jsonKafkaProducer;
	
	Logger logger=LoggerFactory.getLogger(UserProfileController.class);
  
	@Autowired
	public UserProfileController (UserProfileService userProfileService, JsonKafkaProducer jsonKafkaProducer) {
		this.usersProfileService = userProfileService;
		this.jsonKafkaProducer=jsonKafkaProducer;
		
	}

//	@GetMapping
//	public ResponseEntity<Object> getAllUsers() {
//		logger.info("Successfully retrieved data");
//		return new ResponseEntity<>(usersProfileService.getAllUsers(), HttpStatus.OK);
//	}
	

	@GetMapping("/getUser/{id}")
	public ResponseEntity<Object> getUserProfileById(@PathVariable long id) throws ResourceNotFoundException{
		logger.info("Successfully retrieved data for given User Id");
		return new ResponseEntity<>(usersProfileService.getUserProfileById(id), HttpStatus.OK);
	}

	@PostMapping("/register")
	public ResponseEntity<Object> saveUserProfile(@RequestBody UserProfile userProfile) throws ResourceAlreadyExistsException{
		
		//sending registration data to authentication server using java
		
		jsonKafkaProducer.sendMessage(userProfile);
		logger.info("User registered successfully");
		return new ResponseEntity<>(usersProfileService.saveUserProfile(userProfile), HttpStatus.OK);
	}

	@PutMapping("/updateUser/{id}")
	public ResponseEntity<Object> updateUserProfile(@RequestBody UserProfileDto userProfileDto, @PathVariable long id) {
		logger.info("User updated successfully");
		return new ResponseEntity<>(usersProfileService.updateUserProfile(userProfileDto, id), HttpStatus.OK);
	}
//	
//	@GetMapping("/getProfile/{username}")
//	public ResponseEntity<Object> getUserProfileByName(@PathVariable String username) throws ResourceNotFoundException {
//		logger.info("Successfully retrieved data");
//		return new ResponseEntity<>(usersProfileService.getUserByUsername(username), HttpStatus.OK);
//	}
}




	
	