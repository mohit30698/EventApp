package com.cts.event.app.user.kafka;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.stereotype.Service;
import org.springframework.messaging.Message;
import com.cts.event.app.user.entity.UserProfile;
import com.google.gson.Gson;


@Service
public class JsonKafkaProducer {
 @Value("${spring.kafka.topic-json.name}")
 private String topicJsonName;
 
 @Autowired
 Gson gson;

private static final Logger LOGGER = LoggerFactory.getLogger(JsonKafkaProducer.class);

private KafkaTemplate<String, String> kafkaTemplate;

public JsonKafkaProducer(KafkaTemplate<String, String> kafkaTemplate) {
this.kafkaTemplate = kafkaTemplate;

}

public void sendMessage(UserProfile data) {

  LOGGER.info(String.format("Message sent -> %s", data.toString()));

//  Message<UserProfile> message = MessageBuilder.withPayload(data).setHeader(KafkaHeaders.TOPIC, topicJsonName)
//         .build();
  kafkaTemplate.send("eventapp_json",gson.toJson(data));

//   kafkaTemplate.send(message);
}
}
