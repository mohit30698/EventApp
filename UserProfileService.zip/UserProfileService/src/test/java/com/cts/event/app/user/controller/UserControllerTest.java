package com.cts.event.app.user.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;



import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.cts.event.app.user.dto.UserProfileDto;
import com.cts.event.app.user.entity.UserProfile;
import com.cts.event.app.user.kafka.JsonKafkaProducer;
//import com.cts.event.app.user.kafka.JsonKafkaProducer;
import com.cts.event.app.user.service.UserProfileService;


@SpringBootTest
public class UserControllerTest {

	@InjectMocks
	UserProfileController userProfileController;
	

    @Mock
    private JsonKafkaProducer jsonKafkaProducer;


	
	@Mock
	UserProfileService userProfileService;
	
//	  @Test
//	    public void testGetAllUsers() {
//		   UserProfileDto userProfileDto = new UserProfileDto(1, "john_doe", "John", "Doe", "securePassword123",
//	                "john.doe@example.com", "+1234567890", "1990-01-15");
//	    
//	        when(userProfileService.getAllUsers()).thenReturn(List.of(userProfileDto));
//
//	      
//	        ResponseEntity<Object> responseEntity = userProfileController.getAllUsers();
//
//	
//	        assertEquals(responseEntity.getStatusCode(), HttpStatus.OK);
//	        assertEquals(responseEntity.getBody(), List.of(userProfileDto));
//	  
//	    }
//	  
	  
	   @Test
	    public void testGetUserProfileById() {
		   
		   UserProfileDto userProfileDto = new UserProfileDto(1, "john_doe", "John", "Doe", "securePassword123",
	                "john.doe@example.com", "+1234567890", "1990-01-15");
	      
	        long userId = 1L;
	        when(userProfileService.getUserProfileById(userId)).thenReturn(userProfileDto);

	  
	        ResponseEntity<Object> responseEntity = userProfileController.getUserProfileById(userId);

	  
	        assertEquals(responseEntity.getStatusCode(), HttpStatus.OK);
	        assertEquals(responseEntity.getBody(),userProfileDto);
	    
	    }
	   
	   @Test
	    public void testSaveUserProfile() {
	   
		   UserProfileDto userProfileDto = new UserProfileDto(1, "john_doe", "John", "Doe", "securePassword123",
	                "john.doe@example.com", "+1234567890", "1990-01-15");
	        UserProfile userProfile = new UserProfile();
	        when(userProfileService.saveUserProfile(userProfile)).thenReturn(userProfileDto);
	        ResponseEntity<Object> responseEntity = userProfileController.saveUserProfile(userProfile);
	    //   verify(jsonKafkaProducer).sendMessage(userProfile);
	        assertEquals(responseEntity.getStatusCode(), HttpStatus.OK);
	        assertEquals(responseEntity.getBody(), userProfileDto);
	    }
	   
	   @Test
	    public void testUpdateUserProfile() {
		   
		   UserProfileDto userProfileDto = new UserProfileDto(1, "john_doe", "John", "Doe", "securePassword123",
	                "john.doe@example.com", "+1234567890", "1990-01-15");
	        when(userProfileService.updateUserProfile(any(UserProfileDto.class),any(long.class))).thenReturn(userProfileDto);

	
	        ResponseEntity<Object> responseEntity = userProfileController.updateUserProfile(new UserProfileDto(), 1L);

	        assertEquals(responseEntity.getStatusCode(), HttpStatus.OK);
	        assertEquals(responseEntity.getBody(),userProfileDto);
	    }

	   
//	   @Test
//	    public void testGetUserProfileByName() {
//	  
//	        String username = "john_doe";
//	        when(userProfileService.getUserByUsername(username)).thenReturn(Optional.of(new UserProfile()));
//
//	        ResponseEntity<Object> responseEntity = userProfileController.getUserProfileByName(username);
//
//	        assertEquals(responseEntity.getStatusCode(), HttpStatus.OK);
//	    }
	
}

	   