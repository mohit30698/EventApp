package com.event.app.wishlist.repo;

import java.util.List;




import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.event.app.wishlist.model.Event;
import com.event.app.wishlist.model.Wishlist;


@Repository
public interface WishlistRepository extends JpaRepository<Event, Integer>
{

	//Optional<Event> findById(int wishlistid, int perfid);
    
	//Optional<Event> findByOptional();
//	@Query(value="delete from event where wishlistid = '1'",nativeQuery=true)
//	void deleteBywishlistid(int id);
}