package com.event.app.wishlist.service;

import java.util.List;

import com.event.app.wishlist.exception.WishListEventAlreadyExistsException;
import com.event.app.wishlist.exception.WishListEventNotFoundException;
import com.event.app.wishlist.model.Event;
import com.event.app.wishlist.model.Wishlist;

public interface WishlistService {

	public List<Event> getAll() throws WishListEventNotFoundException;

	public Event addWishListEvent(Event wishList) throws WishListEventAlreadyExistsException;

	public Event deleteWishListEvent(int wishlistid) throws WishListEventNotFoundException;

}

