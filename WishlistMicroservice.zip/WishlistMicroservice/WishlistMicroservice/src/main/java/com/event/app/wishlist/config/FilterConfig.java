package com.event.app.wishlist.config;

import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.event.app.wishlist.filter.WishlistFilter;

import io.swagger.v3.oas.models.Components;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.security.SecurityRequirement;
import io.swagger.v3.oas.models.security.SecurityScheme;


/**
 * Indicates this as a configuration class
 */
@Configuration
public class FilterConfig {

	@Bean
	public FilterRegistrationBean jwtUserFilter() {

		FilterRegistrationBean filter = new FilterRegistrationBean();
		filter.setFilter(new WishlistFilter());

		filter.addUrlPatterns("/wishlist/*");

		return filter;

	}
	  @Bean
	   OpenAPI customOpenAPI() {
	      return new OpenAPI()
	            .components(new Components().addSecuritySchemes("bearer-token",
	                  new SecurityScheme().type(SecurityScheme.Type.HTTP).scheme("bearer").bearerFormat("JWT")
	                        .name("Authorization")))
	            .info(new Info().title("WHISLIST-SERVICE")
	                  .description("@author:priya singh auth for event app").version("1.0.0"))
	            .addSecurityItem(new SecurityRequirement().addList("bearer-token"));
	   }
}
