package com.event.app.wishlist.model;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name="event")
public class Event {
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int wishlistid;
	 private String type;
     private long id;
     private String datetime_utc;
     
     @OneToOne(cascade = CascadeType.ALL)
     @JoinColumn(name = "venueid")
     private Venue venue;
     
//    @OneToMany(cascade = CascadeType.ALL)
//    @JoinColumn(name = "perfid")
//    private List<Performer> performers;
     
//    @OneToMany(fetch = FetchType.LAZY, mappedBy = "events",cascade = CascadeType.ALL)
    //@JoinColumn(name = "perfid")
    @OneToMany(cascade = CascadeType.ALL, targetEntity = Performer.class)
    @JoinColumn(name = "performerid", referencedColumnName = "wishlistid")
    @JsonManagedReference
    private List<Performer> performers;
     
//     @OneToMany(mappedBy = "event")
//     private List<Performer> performers;

}