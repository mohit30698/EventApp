package com.event.app.wishlist.filter;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.web.filter.GenericFilterBean;

import io.jsonwebtoken.Jwt;
import io.jsonwebtoken.JwtParser;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.MalformedJwtException;
import io.jsonwebtoken.SignatureException;

import java.io.IOException;
import java.util.Date;

/* This class implements the custom filter by extending org.springframework.web.filter.GenericFilterBean.
 * Override the doFilter method with ServletRequest, ServletResponse and FilterChain.
 * This is used to authorize the API access for the application.
 */
public class WishlistFilter extends GenericFilterBean {

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException

	{

		HttpServletRequest httpreq = (HttpServletRequest) request;
		HttpServletResponse httpres = (HttpServletResponse) response;

		httpres.setHeader("Access-Control-Allow-Origin", "*");
		httpres.setHeader("Access-Control-Allow-Headers", "*");
		httpres.setHeader("Access-Control-Allow-Credentials", "true");
		httpres.setHeader("Access-Control-Allow-Methods", "POST,GET,PUT,DELETE,OPTIONS");

		// to handle preflight request for the first time which is raised by webbrowser
		// ,when UI is based on script

		if (httpreq.getMethod().equals(HttpMethod.OPTIONS.name())) {
			chain.doFilter(httpreq, httpres);
		} else {

			String headerinfo = httpreq.getHeader("Authorization");

			if ((headerinfo == null) || (!headerinfo.startsWith("Bearer"))) {
				throw new ServletException("JWT Token is missing");
			}

			String mytoken = headerinfo.substring(7);

			try {

				JwtParser jwtparser = Jwts.parser().setSigningKey("secret");

				Jwt jwtobj = jwtparser.parse(mytoken);

			} catch (SignatureException e) {
				throw new ServletException("Invalid siganature / token ");
			} catch (MalformedJwtException e) {
				throw new ServletException("Someone illegally modified token");

			}

			chain.doFilter(httpreq, httpres);
		}

	}

}
