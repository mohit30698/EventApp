package com.event.app.wishlist.model;

import jakarta.persistence.Id;


import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Wishlist {

	
	private int wishlistId;
	
	@Column(name = "eventId")
	private long eventId;


	@Column(name = "userId")
	private int userId;

	@Column(name = "userName")
	private String username;


	@Column(name = "eventype")
	private String eventype;

	@Column(name = "datetime_utc")
	private String datetime_utc;

	@Column(name = "venueName")
	private String venueName;


	@Column(name = "venueCapacity")
	private String venueCapacity;

	@Column(name = "performerName")
	private String performerName;
	
	
}

