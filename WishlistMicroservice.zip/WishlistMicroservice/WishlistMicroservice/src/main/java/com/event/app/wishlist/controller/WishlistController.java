package com.event.app.wishlist.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.event.app.wishlist.exception.WishListEventAlreadyExistsException;
import com.event.app.wishlist.exception.WishListEventNotFoundException;
import com.event.app.wishlist.model.Event;
import com.event.app.wishlist.model.Wishlist;
import com.event.app.wishlist.response.ResponseHandler;
import com.event.app.wishlist.service.WishlistService;


@CrossOrigin
@RestController
@RequestMapping("/api/v1.0/wishlistService/wishlist")
public class WishlistController {

	Logger logger=LoggerFactory.getLogger(WishlistController.class);

	private final WishlistService wishlistService;

	@Autowired
	public WishlistController(WishlistService wishlistService) {
		this.wishlistService = wishlistService; 
	}


	@GetMapping("/viewFavourites")
	//public ResponseEntity<Object> viewFavouriteEvent(@RequestHeader(name = "Authorization", required = true) String token,@PathVariable long eventId,@PathVariable int userId) throws WishListEventNotFoundException {
	public ResponseEntity<Object> viewFavouriteEvent() throws WishListEventNotFoundException {
		List<Event> event =wishlistService.getAll();
		logger.info("Event data retrieved successfully!");
		return ResponseHandler.generateResponse("Event data retrieved successfully!", HttpStatus.OK, event);

	} 

	@PostMapping("/addFavourite")
	public ResponseEntity<Object> addFavouriteEvent(@RequestHeader(name = "Authorization", required = true) String token,@RequestBody Event wishlist) throws WishListEventAlreadyExistsException {
		return ResponseHandler.generateResponse("Event added to wishlist successfully!", HttpStatus.CREATED,
				wishlistService.addWishListEvent(wishlist));

	}

	@DeleteMapping("/deleteFavouritem/{wishlistid}")
	public ResponseEntity<Object> deleteFavouriteEvent(@PathVariable int wishlistid) throws WishListEventNotFoundException {
		logger.info("Event deleted from wishlist successfully!");
		return ResponseHandler.generateResponse("Event deleted from wishlist successfully!", HttpStatus.CREATED,
				wishlistService.deleteWishListEvent(wishlistid));
	}
	
	
}