package com.event.app.wishlist.service;

import org.slf4j.Logger;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.event.app.wishlist.exception.WishListEventAlreadyExistsException;
import com.event.app.wishlist.exception.WishListEventNotFoundException;
import com.event.app.wishlist.model.Event;
import com.event.app.wishlist.model.Performer;
import com.event.app.wishlist.model.Wishlist;
import com.event.app.wishlist.repo.WishlistRepository;

import jakarta.transaction.Transactional;

import java.util.ArrayList;
import java.util.List;

//import jakarta.validation.constraints.AssertFalse.List;

import java.util.Optional;

@Service
public class WishlistServiceImpl implements WishlistService {
	
	Logger logger=LoggerFactory.getLogger(WishlistServiceImpl.class);

	private final WishlistRepository wishlistRepository;

	@Autowired
	public WishlistServiceImpl(WishlistRepository wishlistRepository) {
		this.wishlistRepository = wishlistRepository;

	}

//	@Override
//	public Wishlist getWishListEvent(long eventId, int userId) throws WishListEventNotFoundException {
//
//		Optional<Wishlist> optional = wishlistRepository.findByEventIdAndUserId(eventId, userId);
//		if (optional.isPresent()) {
//			//logger.info("Retrieved event from Wishlist");
//			return optional.get();
//		}
//		//logger.error("Event not found in Wishlist");
//		throw new WishListEventNotFoundException("Event not found in Wishlist");
//	}

	@Override
	public Event addWishListEvent(Event wishlist) throws WishListEventAlreadyExistsException {
//		List<Performer> performer = new ArrayList<Performer>();
//		wishlist.ge
			
		return wishlistRepository.save(wishlist);
	}

	@Override
	public java.util.List<Event> getAll() throws WishListEventNotFoundException {
		// TODO Auto-generated method stub
		return wishlistRepository.findAll();
	}

	@Override
	@Transactional
	public Event deleteWishListEvent(int wishlistid) throws WishListEventNotFoundException {
		Optional<Event> optional = wishlistRepository.findById(wishlistid);
		if (optional.isPresent()) {
			wishlistRepository.deleteById(optional.get().getWishlistid());
			//logger.info("Event in wishlist is deleted");
			return optional.get();
		}
		//logger.error("Event is not found in Wishlist");
		throw new WishListEventNotFoundException("Event is not found in Wishlist");
	}

}