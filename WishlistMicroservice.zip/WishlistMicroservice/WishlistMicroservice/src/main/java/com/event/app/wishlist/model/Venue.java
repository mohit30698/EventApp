package com.event.app.wishlist.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name="venue")
public class Venue {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int venueid;
	private String name;
	private String capacity;
	private String country;
}