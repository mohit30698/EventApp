package com.event.app.wishlist.exception;
public class WishListEventNotFoundException extends Exception {

	public WishListEventNotFoundException(String msg)
	{
		super(msg);
	}
}
