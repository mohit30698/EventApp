package com.event.app.wishlist.exception;


public class WishListEventAlreadyExistsException extends Exception {

	public WishListEventAlreadyExistsException(String msg)
	{
		super(msg);
	}
}