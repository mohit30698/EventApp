//package com.event.app.wishlist.controller;
//
//import org.junit.jupiter.api.AfterEach;
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//import org.junit.jupiter.api.extension.ExtendWith;
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
//import org.mockito.MockitoAnnotations;
//import org.mockito.junit.jupiter.MockitoExtension;
//import org.mockito.junit.jupiter.MockitoSettings;
//import org.mockito.quality.Strictness;
//import org.springframework.http.MediaType;
//import org.springframework.test.web.servlet.MockMvc;
//import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
//import org.springframework.test.web.servlet.setup.MockMvcBuilders;
//
//import com.event.app.wishlist.model.Wishlist;
//import com.event.app.wishlist.service.WishlistServiceImpl;
//import com.fasterxml.jackson.databind.ObjectMapper;
//
//import static org.mockito.Mockito.when;
//import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
//import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
//
// 
//@ExtendWith(MockitoExtension.class)
//@MockitoSettings(strictness = Strictness.LENIENT)
//public class WishListControllerTest {
// 
//
//    private MockMvc mockMvc;
//    
//    @Mock
//    private WishlistServiceImpl wishlistService;
//    
//    @InjectMocks
//    private WishlistController wishlistController;
//    
//    private Wishlist event;
//
//
//    @BeforeEach
//    public void setUp() {
//        MockitoAnnotations.initMocks(this);
//        mockMvc = MockMvcBuilders.standaloneSetup(wishlistController).build();
//        event = new Wishlist(1, 1l, 1, "john", "football", "2023-12-04T08:30:00", "football park", "1000",
//				"Ronald");
//       
//    }
//
//    @AfterEach
//    public void tearDown() {
//        event = null;
//    }
//
//   // @Test
//   // void givenEventToSaveThenShouldReturnSavedEvent() throws Exception {
//     //   when(wishlistService.addWishListEvent(event)).thenReturn(event);
//       // mockMvc.perform(post("/wishlist/addFavourite").header("Authorization","token")
//         //       .contentType(MediaType.APPLICATION_JSON)
//           //     .content(asJsonString(event)))
//             //   .andExpect(status().isCreated())
//               // .andDo(MockMvcResultHandlers.print());
//   // }
//    @Test
//    void givenEventToSaveThenShouldReturnSavedEvent() throws Exception {
//        // Mocking service behavior
//        when(wishlistService.addWishListEvent(event)).thenReturn(event);
//
//        // Performing the actual method invocation
//        mockMvc.perform(post("/wishlist/addFavourite")
//                .header("Authorization", "token")
//                .contentType(MediaType.APPLICATION_JSON)
//                .content(asJsonString(event)))
//                // Adjust the assertion based on the actual status returned by the controller
//                //.andExpect(status().isOk()) // or .andExpect(status().isCreated()) based on the actual status
//                .andExpect(status().is2xxSuccessful()) 
//                .andDo(MockMvcResultHandlers.print());
//        //mvcResult.andDo(MockMvcResultHandlers.print());
//
//    }
//
// 
//
//    
//    @Test
//    void givenEventAndUserIdThenShouldReturnWishListEvent() throws Exception {
//    	when(wishlistService.getWishListEvent(1l,1)).thenReturn(event);
//        mockMvc.perform(get("/wishlist/viewFavourite/{eventId}/{userId}",1l,1)
//        		.header("Authorization","token")
//                .contentType(MediaType.APPLICATION_JSON).content(asJsonString(event)))
//                .andDo(MockMvcResultHandlers.print());
//    
//    }
//    
//    @Test 
//    void givenEventAndUserIdThenShouldDeleteWishListEvent() throws Exception {
//    	when(wishlistService.deleteWishListEvent(1l,1)).thenReturn(event);
//        mockMvc.perform(delete("/wishlist/deleteFavourite/{eventId}/{userId}",1l,1)
//        		.header("Authorization","token")
//                .contentType(MediaType.APPLICATION_JSON).content(asJsonString(event)))
//                .andDo(MockMvcResultHandlers.print());
// 
//    }
//
//    public static String asJsonString(final Object obj) {
//        try {
//            return new ObjectMapper().writeValueAsString(obj);
//        } catch (Exception e) {
//            throw new RuntimeException(e);
//        }
//    }
//
//}