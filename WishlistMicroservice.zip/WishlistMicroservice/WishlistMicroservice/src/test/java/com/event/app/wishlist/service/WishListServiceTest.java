//package com.event.app.wishlist.service;
//
//import static org.junit.jupiter.api.Assertions.assertNotNull;
//import static org.junit.jupiter.api.Assertions.assertThrows;
//import static org.mockito.Mockito.*;
//import java.util.Optional;
//import org.junit.jupiter.api.Test;
//import org.junit.jupiter.api.extension.ExtendWith;
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
//import org.mockito.junit.jupiter.MockitoExtension;
//
//import com.event.app.wishlist.exception.WishListEventAlreadyExistsException;
//import com.event.app.wishlist.exception.WishListEventNotFoundException;
//import com.event.app.wishlist.model.Wishlist;
//import com.event.app.wishlist.repo.WishlistRepository;
//
//
//@ExtendWith(MockitoExtension.class)
//class WishListServiceTest {
//
//	@Mock
//	private WishlistRepository wishlistRepository;
//
//	@InjectMocks
//	private WishlistServiceImpl wishlistService;
//
//	@Test
//    void givenEventAndUserIdThenShouldReturnRespectiveWishListEvent() throws WishListEventNotFoundException{
//		
//        when(wishlistRepository.findByEventIdAndUserId(1l,1)).thenReturn(Optional.of(new Wishlist()));
//        Wishlist wishlist = wishlistService.getWishListEvent(1l,1);
//        assertNotNull(wishlist);
//    }
//
//	@Test
//	void givenNonExistEventAndUserIdThenShouldThrowWishListEventNotFoundException() {
//		
//		 when(wishlistRepository.findByEventIdAndUserId(1l,1)).thenReturn(Optional.empty());
//	      assertThrows(WishListEventNotFoundException.class,()->wishlistService.getWishListEvent(1l,1));
//		verify(wishlistRepository,times(1)).findByEventIdAndUserId(1l,1);
//	}
//
//	@Test
//	void givenWishlistEventToSaveThenShouldReturnSavedWishlistEvent()
//			throws WishListEventNotFoundException, WishListEventAlreadyExistsException {
//		Wishlist wishlist = new Wishlist(1, 1l, 1, "john", "football", "2023-12-04T08:30:00", "football park", "1000",
//				"Ronald");
//		when(wishlistRepository.findByEventIdAndUserId(1l, 1)).thenReturn(Optional.empty());
//		wishlistService.addWishListEvent(wishlist);
//		verify(wishlistRepository, times(1)).findByEventIdAndUserId(1l, 1);
//	}
//
//	@Test
//	void givenExistEventAndUserIdThenShouldThrowWishListEventAlreadyExistsException() {
//
//		Wishlist wishlist = new Wishlist(1, 1l, 1, "john", "football", "2023-12-04T08:30:00", "football park", "1000",
//				"Ronald");
//		wishlistRepository.save(wishlist);
//		when(wishlistRepository.findByEventIdAndUserId(1l, 1)).thenReturn(Optional.of(wishlist));
//		assertThrows(WishListEventAlreadyExistsException.class, () -> wishlistService.addWishListEvent(wishlist));
//		verify(wishlistRepository, times(1)).findByEventIdAndUserId(1l, 1);
//	}
//
//	@Test
//	void givenEventAndUserIdThenShouldDeleteRespectiveWishListEvent() throws WishListEventNotFoundException {
//		Wishlist wishlist = new Wishlist(1, 1l, 1, "john", "football", "2023-12-04T08:30:00", "football park", "1000",
//				"Ronald");
//		wishlistRepository.save(wishlist);
//		when(wishlistRepository.findByEventIdAndUserId(1l, 1)).thenReturn(Optional.of(wishlist));
//		wishlistService.deleteWishListEvent(1l, 1);
//		verify(wishlistRepository, times(1)).findByEventIdAndUserId(1l, 1);
//	}
//
//	@Test
//	void givenNonExistEventAndUserIdThenShouldThrowsWishListEventNotFoundException() {
//
//		
//
//		when(wishlistRepository.findByEventIdAndUserId(1l, 1)).thenReturn(Optional.empty());
//
//		assertThrows(WishListEventNotFoundException.class, () -> wishlistService.deleteWishListEvent(1l, 1));
//		verify(wishlistRepository, times(1)).findByEventIdAndUserId(1l, 1);
//	}
//
//}
